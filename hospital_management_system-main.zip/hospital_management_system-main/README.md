"Hospital Management System" is the Project for the course CS-222 Database Management System in the 4th semester of the Computer & Information Systems Engineering at NED University of Engineering and Technology. 


Created using mysql for back-end and php(sublime-text3) for front-end.


The repository contains complete zip file. 


Here is some authentication info for admin login;

Username: admin_vpr

Password: prince123




For any further cooperations or details regarding this project you can email at vedeeka2020@gmail.com or reach me at LinkedIn: https://www.linkedin.com/in/vedeeka-rajpal-96a838293
